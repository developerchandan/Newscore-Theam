jQuery(document).ready(function(){
	
	/*
	 *
	 * Radium_Options_date function
	 * Adds datepicker js
	 *
	 */
	jQuery('.radium-opts-datepicker').datepicker();
	
});