<?php

add_filter('body_class','radium_browser_body_class');
add_filter( 'wp_page_menu_args', 'radium_home_page_menu_args' );
